//
//  @@PROJECTNAME@@Switch.h
//  @@FULLPROJECTNAME@@
//
//  Created by @@USER@@ on @@DATE@@.
//  Copyright (c) @@YEAR@@ @@USER@@. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "FSSwitchDataSource.h"
#import "FSSwitchPanel.h"

@interface @@PROJECTNAME@@Switch : NSObject <FSSwitchDataSource>

@end