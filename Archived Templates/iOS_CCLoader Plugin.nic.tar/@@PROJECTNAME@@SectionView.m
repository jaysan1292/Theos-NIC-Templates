//
//  @@PROJECTNAME@@SectionView.m
//  @@FULLPROJECTNAME@@
//
//  Created by @@USER@@ on @@DATE@@.
//  Copyright (c) @@YEAR@@ @@USER@@. All rights reserved.
//

#import "@@PROJECTNAME@@SectionView.h"

@implementation @@PROJECTNAME@@SectionView

- (instancetype)init {
    self = [super init];
    if (self) {
        //Load additional views
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    //Layout any subviews
}

@end
